import React from 'react';
import { TrendingUp, Clock, Users, Heart, Award, Calendar, BarChart3, Target } from 'lucide-react';

interface AnalyticsProps {
  stats: {
    activeEmergencies: number;
    availableCoaches: number;
    responseTime: string;
    successRate: string;
    liveSaved: number;
  };
}

const Analytics: React.FC<AnalyticsProps> = ({ stats }) => {
  const monthlyData = [
    { month: 'Jan', emergencies: 245, responseTime: 7.2, successRate: 94 },
    { month: 'Feb', emergencies: 189, responseTime: 6.8, successRate: 95 },
    { month: 'Mar', emergencies: 267, responseTime: 6.5, successRate: 96 },
    { month: 'Apr', emergencies: 298, responseTime: 6.1, successRate: 97 },
    { month: 'May', emergencies: 312, responseTime: 5.9, successRate: 96 },
    { month: 'Jun', emergencies: 278, responseTime: 6.2, successRate: 96 }
  ];

  const performanceMetrics = [
    { label: 'Average Response Time', value: '6.2 min', change: '-8%', trend: 'down', color: 'green' },
    { label: 'Success Rate', value: '96%', change: '+2%', trend: 'up', color: 'green' },
    { label: 'Patient Satisfaction', value: '4.8/5', change: '+0.3', trend: 'up', color: 'green' },
    { label: 'System Uptime', value: '99.7%', change: '+0.2%', trend: 'up', color: 'green' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h2>
            <p className="text-gray-600 mt-1">Performance metrics and system insights</p>
          </div>
          <div className="flex items-center space-x-2 px-4 py-2 bg-blue-100 rounded-lg">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-800">Live Data</span>
          </div>
        </div>
      </div>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {performanceMetrics.map((metric, index) => (
          <div key={index} className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-gray-600">{metric.label}</h4>
              <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${
                metric.color === 'green' ? 'text-green-600 bg-green-100' : 'text-red-600 bg-red-100'
              }`}>
                <TrendingUp className={`w-3 h-3 ${metric.trend === 'down' ? 'rotate-180' : ''}`} />
                <span>{metric.change}</span>
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
          </div>
        ))}
      </div>

      {/* Monthly Trends Chart */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Monthly Performance Trends</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Response Time Chart */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Average Response Time (minutes)</h4>
            <div className="space-y-3">
              {monthlyData.map((data, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <span className="w-8 text-sm text-gray-600">{data.month}</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${(8 - data.responseTime) / 8 * 100}%` }}
                    ></div>
                  </div>
                  <span className="w-12 text-sm font-medium text-gray-900">{data.responseTime}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Emergency Volume Chart */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Monthly Emergency Volume</h4>
            <div className="space-y-3">
              {monthlyData.map((data, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <span className="w-8 text-sm text-gray-600">{data.month}</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-green-500 to-green-600 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${data.emergencies / 350 * 100}%` }}
                    ></div>
                  </div>
                  <span className="w-12 text-sm font-medium text-gray-900">{data.emergencies}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Impact Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Heart className="w-8 h-8 text-red-200" />
            <Target className="w-6 h-6 text-red-200" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Lives Saved</h3>
          <p className="text-3xl font-bold mb-1">{stats.liveSaved}</p>
          <p className="text-red-200 text-sm">Since system launch</p>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Clock className="w-8 h-8 text-blue-200" />
            <TrendingUp className="w-6 h-6 text-blue-200" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Time Saved</h3>
          <p className="text-3xl font-bold mb-1">18,690</p>
          <p className="text-blue-200 text-sm">Minutes saved in total</p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <Award className="w-8 h-8 text-green-200" />
            <Users className="w-6 h-6 text-green-200" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Families Helped</h3>
          <p className="text-3xl font-bold mb-1">4,238</p>
          <p className="text-green-200 text-sm">Families served</p>
        </div>
      </div>

      {/* Comparative Analysis */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">System vs Traditional Ambulance</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Response Time Comparison</h4>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Lifeline Metro System</span>
                  <span className="text-sm font-medium text-green-600">6.2 minutes</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '31%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Traditional Ambulance</span>
                  <span className="text-sm font-medium text-red-600">20.5 minutes</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-gray-900 mb-4">Success Rate Comparison</h4>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Lifeline Metro System</span>
                  <span className="text-sm font-medium text-green-600">96%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '96%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Traditional System</span>
                  <span className="text-sm font-medium text-orange-600">78%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-orange-500 h-2 rounded-full" style={{ width: '78%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <div>
              <h5 className="font-semibold text-blue-900">System Impact Summary</h5>
              <p className="text-sm text-blue-800">
                Lifeline Metro has improved emergency response times by 70% and increased success rates by 18% compared to traditional ambulance systems.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
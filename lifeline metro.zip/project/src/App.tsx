import React, { useState, useEffect } from 'react';
import { Activity, Ambulance, Train, Guitar as Hospital, MapPin, Clock, Users, AlertTriangle, CheckCircle, Timer, Heart, Zap } from 'lucide-react';
import Dashboard from './components/Dashboard';
import EmergencyDispatch from './components/EmergencyDispatch';
import LiveTracking from './components/LiveTracking';
import MetroStatus from './components/MetroStatus';
import Analytics from './components/Analytics';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [emergencies, setEmergencies] = useState([
    {
      id: 'EM001',
      patientName: 'Rajesh Kumar',
      status: 'in-transit',
      priority: 'critical',
      location: 'MG Road Metro Station',
      destination: 'Apollo Hospital',
      estimatedTime: '8 min',
      stage: 'metro-transfer'
    },
    {
      id: 'EM002',
      patientName: 'Priya Sharma',
      status: 'dispatched',
      priority: 'high',
      location: 'Indiranagar',
      destination: 'Manipal Hospital',
      estimatedTime: '12 min',
      stage: 'bike-ambulance'
    }
  ]);

  const [systemStats, setSystemStats] = useState({
    activeEmergencies: 2,
    availableCoaches: 8,
    responseTime: '6.2 min',
    successRate: '96%',
    liveSaved: 1247
  });

  const tabs = [
    { id: 'dashboard', label: 'System Overview', icon: Activity },
    { id: 'dispatch', label: 'Emergency Dispatch', icon: Ambulance },
    { id: 'tracking', label: 'Live Tracking', icon: MapPin },
    { id: 'metro', label: 'Metro Status', icon: Train },
    { id: 'analytics', label: 'Analytics', icon: Users }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard emergencies={emergencies} stats={systemStats} />;
      case 'dispatch':
        return <EmergencyDispatch emergencies={emergencies} setEmergencies={setEmergencies} />;
      case 'tracking':
        return <LiveTracking emergencies={emergencies} />;
      case 'metro':
        return <MetroStatus />;
      case 'analytics':
        return <Analytics stats={systemStats} />;
      default:
        return <Dashboard emergencies={emergencies} stats={systemStats} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl">
                <Heart className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Lifeline Metro</h1>
                <p className="text-sm text-gray-600">Smart Emergency Transport System</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2 px-4 py-2 bg-green-100 rounded-lg">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-green-800">System Operational</span>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Lives Saved</p>
                <p className="text-xl font-bold text-blue-600">{systemStats.liveSaved}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Navigation Tabs */}
        <nav className="bg-white rounded-xl shadow-md p-2 mb-6">
          <div className="flex space-x-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-gray-600 hover:bg-blue-50 hover:text-blue-600'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </nav>

        {/* Main Content */}
        <div className="transition-all duration-300">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

export default App;
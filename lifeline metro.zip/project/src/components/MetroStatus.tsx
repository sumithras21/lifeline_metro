import React from 'react';
import { Train, Zap, Users, Wrench, CheckCircle, AlertTriangle, Battery, Wifi } from 'lucide-react';

const MetroStatus: React.FC = () => {
  const metroLines = [
    { id: 'Blue Line', status: 'operational', coaches: 12, available: 8, maintenance: 1 },
    { id: 'Purple Line', status: 'operational', coaches: 10, available: 7, maintenance: 0 },
    { id: 'Green Line', status: 'operational', coaches: 8, available: 6, maintenance: 1 },
    { id: 'Red Line', status: 'maintenance', coaches: 6, available: 3, maintenance: 2 }
  ];

  const medicalCoaches = [
    { id: 'MC-001', line: 'Blue Line', station: 'MG Road', status: 'in-use', battery: 95, equipment: 'fully-stocked' },
    { id: 'MC-002', line: 'Blue Line', station: 'City Center', status: 'available', battery: 88, equipment: 'fully-stocked' },
    { id: 'MC-003', line: 'Purple Line', station: 'Tech Park', status: 'available', battery: 92, equipment: 'fully-stocked' },
    { id: 'MC-004', line: 'Green Line', station: 'Hospital Junction', status: 'maintenance', battery: 0, equipment: 'restocking' },
    { id: 'MC-005', line: 'Purple Line', station: 'Airport', status: 'available', battery: 85, equipment: 'fully-stocked' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'text-green-600 bg-green-100';
      case 'in-use': return 'text-blue-600 bg-blue-100';
      case 'available': return 'text-green-600 bg-green-100';
      case 'maintenance': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational':
      case 'available': return <CheckCircle className="w-4 h-4" />;
      case 'in-use': return <Zap className="w-4 h-4" />;
      case 'maintenance': return <Wrench className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Metro System Status</h2>
            <p className="text-gray-600 mt-1">Real-time monitoring of metro lines and medical coaches</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">28</p>
              <p className="text-sm text-gray-600">Total Coaches</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">24</p>
              <p className="text-sm text-gray-600">Available</p>
            </div>
          </div>
        </div>
      </div>

      {/* Metro Lines Overview */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Metro Lines Status</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {metroLines.map((line) => (
            <div key={line.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <Train className="w-6 h-6 text-blue-600" />
                  <h4 className="font-semibold text-gray-900">{line.id}</h4>
                </div>
                <span className={`flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(line.status)}`}>
                  {getStatusIcon(line.status)}
                  <span>{line.status.toUpperCase()}</span>
                </span>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-lg font-bold text-gray-900">{line.coaches}</p>
                  <p className="text-xs text-gray-600">Total Coaches</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-green-600">{line.available}</p>
                  <p className="text-xs text-gray-600">Available</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-orange-600">{line.maintenance}</p>
                  <p className="text-xs text-gray-600">Maintenance</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Medical Coaches Detail */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Medical Coaches Status</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Coach ID</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Metro Line</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Current Station</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Battery</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Equipment</th>
              </tr>
            </thead>
            <tbody>
              {medicalCoaches.map((coach) => (
                <tr key={coach.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <span className="font-medium text-gray-900">{coach.id}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-gray-700">{coach.line}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-gray-700">{coach.station}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium w-fit ${getStatusColor(coach.status)}`}>
                      {getStatusIcon(coach.status)}
                      <span>{coach.status.toUpperCase()}</span>
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-2">
                      <Battery className={`w-4 h-4 ${coach.battery > 80 ? 'text-green-600' : coach.battery > 50 ? 'text-yellow-600' : 'text-red-600'}`} />
                      <span className="text-sm font-medium">{coach.battery}%</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      coach.equipment === 'fully-stocked' ? 'text-green-600 bg-green-100' : 'text-orange-600 bg-orange-100'
                    }`}>
                      {coach.equipment.replace('-', ' ').toUpperCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* System Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900">Network Connectivity</h4>
            <Wifi className="w-6 h-6 text-green-600" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">IoT Sensors</span>
              <span className="text-sm font-medium text-green-600">98% Online</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Communication Links</span>
              <span className="text-sm font-medium text-green-600">100% Active</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">GPS Tracking</span>
              <span className="text-sm font-medium text-green-600">99% Accuracy</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900">Medical Equipment</h4>
            <CheckCircle className="w-6 h-6 text-green-600" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Defibrillators</span>
              <span className="text-sm font-medium text-green-600">24/28 Ready</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Oxygen Systems</span>
              <span className="text-sm font-medium text-green-600">27/28 Ready</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Medical Supplies</span>
              <span className="text-sm font-medium text-yellow-600">85% Stocked</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900">Power Systems</h4>
            <Battery className="w-6 h-6 text-green-600" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Main Power</span>
              <span className="text-sm font-medium text-green-600">100% Normal</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Backup Systems</span>
              <span className="text-sm font-medium text-green-600">Ready</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">UPS Status</span>
              <span className="text-sm font-medium text-green-600">Charging</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MetroStatus;
import React, { useState } from 'react';
import { Plus, Phone, MapPin, Clock, User, AlertTriangle } from 'lucide-react';

interface Emergency {
  id: string;
  patientName: string;
  status: string;
  priority: string;
  location: string;
  destination: string;
  estimatedTime: string;
  stage: string;
}

interface EmergencyDispatchProps {
  emergencies: Emergency[];
  setEmergencies: React.Dispatch<React.SetStateAction<Emergency[]>>;
}

const EmergencyDispatch: React.FC<EmergencyDispatchProps> = ({ emergencies, setEmergencies }) => {
  const [showNewEmergency, setShowNewEmergency] = useState(false);
  const [formData, setFormData] = useState({
    patientName: '',
    location: '',
    priority: 'high',
    description: '',
    contactNumber: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newEmergency: Emergency = {
      id: `EM${String(emergencies.length + 3).padStart(3, '0')}`,
      patientName: formData.patientName,
      status: 'dispatched',
      priority: formData.priority,
      location: formData.location,
      destination: 'Nearest Hospital',
      estimatedTime: '15 min',
      stage: 'bike-ambulance'
    };
    setEmergencies([...emergencies, newEmergency]);
    setFormData({
      patientName: '',
      location: '',
      priority: 'high',
      description: '',
      contactNumber: ''
    });
    setShowNewEmergency(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Emergency Dispatch Center</h2>
            <p className="text-gray-600 mt-1">Coordinate emergency responses across the metro network</p>
          </div>
          <button
            onClick={() => setShowNewEmergency(true)}
            className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>New Emergency</span>
          </button>
        </div>
      </div>

      {/* New Emergency Form */}
      {showNewEmergency && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Report New Emergency</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="patientName" className="block text-sm font-medium text-gray-700 mb-2">
                  Patient Name
                </label>
                <input
                  type="text"
                  id="patientName"
                  name="patientName"
                  value={formData.patientName}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter patient name"
                />
              </div>
              
              <div>
                <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-2">
                  Contact Number
                </label>
                <input
                  type="tel"
                  id="contactNumber"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Contact number"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Current location"
                />
              </div>
              
              <div>
                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-2">
                  Priority Level
                </label>
                <select
                  id="priority"
                  name="priority"
                  value={formData.priority}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="critical">Critical</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                Emergency Description
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Brief description of the emergency"
              />
            </div>

            <div className="flex space-x-4">
              <button
                type="submit"
                className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <AlertTriangle className="w-5 h-5" />
                <span>Dispatch Emergency</span>
              </button>
              <button
                type="button"
                onClick={() => setShowNewEmergency(false)}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Emergency Queue */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Emergency Queue</h3>
        <div className="space-y-4">
          {emergencies.map((emergency) => (
            <div key={emergency.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-lg">
                    <User className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{emergency.patientName}</h4>
                    <p className="text-sm text-gray-600 flex items-center space-x-1">
                      <MapPin className="w-4 h-4" />
                      <span>{emergency.location}</span>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    emergency.priority === 'critical' ? 'text-red-600 bg-red-100' :
                    emergency.priority === 'high' ? 'text-orange-600 bg-orange-100' :
                    emergency.priority === 'medium' ? 'text-yellow-600 bg-yellow-100' :
                    'text-green-600 bg-green-100'
                  }`}>
                    {emergency.priority.toUpperCase()}
                  </span>
                  
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>ETA: {emergency.estimatedTime}</span>
                    </p>
                    <p className="text-xs text-gray-600">{emergency.status}</p>
                  </div>
                  
                  <button className="flex items-center justify-center w-10 h-10 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition-colors">
                    <Phone className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EmergencyDispatch;
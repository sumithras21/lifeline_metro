import React from 'react';
import { Activity, Ambulance, Train, Guitar as Hospital, Clock, TrendingUp, Users, Zap, AlertTriangle, CheckCircle } from 'lucide-react';

interface DashboardProps {
  emergencies: Array<{
    id: string;
    patientName: string;
    status: string;
    priority: string;
    location: string;
    destination: string;
    estimatedTime: string;
    stage: string;
  }>;
  stats: {
    activeEmergencies: number;
    availableCoaches: number;
    responseTime: string;
    successRate: string;
    liveSaved: number;
  };
}

const Dashboard: React.FC<DashboardProps> = ({ emergencies, stats }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-green-600 bg-green-100';
    }
  };

  const getStageIcon = (stage: string) => {
    switch (stage) {
      case 'bike-ambulance': return <Ambulance className="w-5 h-5 text-blue-600" />;
      case 'metro-transfer': return <Train className="w-5 h-5 text-purple-600" />;
      case 'hospital-delivery': return <Hospital className="w-5 h-5 text-green-600" />;
      default: return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStageLabel = (stage: string) => {
    switch (stage) {
      case 'bike-ambulance': return 'Bike Ambulance En Route';
      case 'metro-transfer': return 'Metro Medical Coach';
      case 'hospital-delivery': return 'Hospital Handover';
      default: return 'Processing';
    }
  };

  return (
    <div className="space-y-6">
      {/* System Overview */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">System Overview</h2>
          <div className="flex items-center space-x-2 text-green-600">
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">All Systems Operational</span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm">Active Emergencies</p>
                <p className="text-3xl font-bold">{stats.activeEmergencies}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Available Coaches</p>
                <p className="text-3xl font-bold">{stats.availableCoaches}</p>
              </div>
              <Train className="w-8 h-8 text-blue-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Avg Response Time</p>
                <p className="text-3xl font-bold">{stats.responseTime}</p>
              </div>
              <Clock className="w-8 h-8 text-green-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Success Rate</p>
                <p className="text-3xl font-bold">{stats.successRate}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-200" />
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">How Lifeline Metro Works</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mx-auto mb-4">
              <Ambulance className="w-8 h-8 text-blue-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">1. Bike Ambulance</h4>
            <p className="text-sm text-gray-600">Quick response team reaches patient and provides initial care</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mx-auto mb-4">
              <Train className="w-8 h-8 text-purple-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">2. Metro Transfer</h4>
            <p className="text-sm text-gray-600">Patient transferred to medical metro coach with advanced equipment</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full mx-auto mb-4">
              <Zap className="w-8 h-8 text-indigo-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">3. Priority Route</h4>
            <p className="text-sm text-gray-600">AI-optimized route ensures fastest possible transport</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mx-auto mb-4">
              <Hospital className="w-8 h-8 text-green-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">4. Hospital Delivery</h4>
            <p className="text-sm text-gray-600">Seamless handover to hospital medical team</p>
          </div>
        </div>
      </div>

      {/* Active Emergencies */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Active Emergency Cases</h3>
        <div className="space-y-4">
          {emergencies.map((emergency) => (
            <div key={emergency.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    {getStageIcon(emergency.stage)}
                    <span className="font-medium text-gray-900">{emergency.id}</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{emergency.patientName}</p>
                    <p className="text-sm text-gray-600">{getStageLabel(emergency.stage)}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(emergency.priority)}`}>
                    {emergency.priority.toUpperCase()}
                  </span>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">ETA: {emergency.estimatedTime}</p>
                    <p className="text-xs text-gray-600">{emergency.location} → {emergency.destination}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
import React from 'react';
import { MapPin, Navigation, Clock, Activity, Ambulance, Train, Guitar as Hospital } from 'lucide-react';

interface Emergency {
  id: string;
  patientName: string;
  status: string;
  priority: string;
  location: string;
  destination: string;
  estimatedTime: string;
  stage: string;
}

interface LiveTrackingProps {
  emergencies: Emergency[];
}

const LiveTracking: React.FC<LiveTrackingProps> = ({ emergencies }) => {
  const getStageProgress = (stage: string) => {
    switch (stage) {
      case 'bike-ambulance': return 25;
      case 'metro-transfer': return 50;
      case 'metro-transit': return 75;
      case 'hospital-delivery': return 100;
      default: return 0;
    }
  };

  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'bike-ambulance': return 'text-blue-600 bg-blue-100';
      case 'metro-transfer': return 'text-purple-600 bg-purple-100';
      case 'metro-transit': return 'text-indigo-600 bg-indigo-100';
      case 'hospital-delivery': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Live Tracking</h2>
            <p className="text-gray-600 mt-1">Real-time monitoring of emergency transports</p>
          </div>
          <div className="flex items-center space-x-2 px-4 py-2 bg-green-100 rounded-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-green-800">Live Updates</span>
          </div>
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">City Metro Network</h3>
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg p-8 h-96 flex items-center justify-center relative overflow-hidden">
          {/* Metro Lines */}
          <div className="absolute inset-0">
            {/* Blue Line */}
            <div className="absolute top-1/3 left-0 right-0 h-2 bg-blue-400 rounded-full opacity-70"></div>
            {/* Purple Line */}
            <div className="absolute left-1/3 top-0 bottom-0 w-2 bg-purple-400 rounded-full opacity-70"></div>
            {/* Green Line */}
            <div className="absolute top-2/3 left-0 right-0 h-2 bg-green-400 rounded-full opacity-70"></div>
          </div>
          
          {/* Active Emergencies on Map */}
          <div className="absolute top-1/4 left-1/4 flex items-center justify-center w-8 h-8 bg-red-500 rounded-full text-white animate-pulse">
            <Ambulance className="w-4 h-4" />
          </div>
          <div className="absolute top-1/2 left-1/2 flex items-center justify-center w-8 h-8 bg-purple-500 rounded-full text-white animate-pulse">
            <Train className="w-4 h-4" />
          </div>
          
          <div className="text-center">
            <MapPin className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h4 className="text-xl font-semibold text-gray-700">Interactive Map</h4>
            <p className="text-gray-500">Real-time visualization of emergency routes</p>
          </div>
        </div>
      </div>

      {/* Emergency Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {emergencies.map((emergency) => (
          <div key={emergency.id} className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h4 className="text-lg font-bold text-gray-900">{emergency.patientName}</h4>
                <p className="text-sm text-gray-600">{emergency.id}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                emergency.priority === 'critical' ? 'text-red-600 bg-red-100' :
                emergency.priority === 'high' ? 'text-orange-600 bg-orange-100' :
                'text-yellow-600 bg-yellow-100'
              }`}>
                {emergency.priority.toUpperCase()}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Transport Progress</span>
                <span className="text-sm text-gray-600">{getStageProgress(emergency.stage)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${getStageProgress(emergency.stage)}%` }}
                ></div>
              </div>
            </div>

            {/* Timeline Steps */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  emergency.stage === 'bike-ambulance' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  <Ambulance className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Bike Ambulance Dispatch</p>
                  <p className="text-sm text-gray-600">{emergency.location}</p>
                </div>
                {emergency.stage === 'bike-ambulance' && (
                  <div className="flex items-center space-x-1">
                    <Activity className="w-4 h-4 text-blue-500 animate-pulse" />
                    <span className="text-sm text-blue-600 font-medium">Active</span>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  emergency.stage === 'metro-transfer' ? 'bg-purple-500 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  <Train className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Metro Medical Coach</p>
                  <p className="text-sm text-gray-600">Nearest Metro Station</p>
                </div>
                {emergency.stage === 'metro-transfer' && (
                  <div className="flex items-center space-x-1">
                    <Activity className="w-4 h-4 text-purple-500 animate-pulse" />
                    <span className="text-sm text-purple-600 font-medium">Active</span>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  emergency.stage === 'hospital-delivery' ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  <Hospital className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Hospital Delivery</p>
                  <p className="text-sm text-gray-600">{emergency.destination}</p>
                </div>
                {emergency.stage === 'hospital-delivery' && (
                  <div className="flex items-center space-x-1">
                    <Activity className="w-4 h-4 text-green-500 animate-pulse" />
                    <span className="text-sm text-green-600 font-medium">Active</span>
                  </div>
                )}
              </div>
            </div>

            {/* ETA */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">Estimated Time</span>
                </div>
                <span className="text-lg font-bold text-blue-600">{emergency.estimatedTime}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LiveTracking;